import javax.swing.*;
import javax.swing.undo.UndoManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class Managefunction extends JFrame implements ActionListener {
    UndoManager undoManager = new UndoManager();


    public Managefunction(){
        Main.item_undo.addActionListener(this);
        Main.item_undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
        Main.item_redo.addActionListener(this);
        Main.item_redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
        Main.item_cut.addActionListener(this);
        Main.item_cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_MASK));
        Main.item_copy.addActionListener(this);
        Main.item_copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
        Main.item_paste.addActionListener(this);
        Main.item_paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
        Main.edit_text_area.getDocument().addUndoableEditListener(undoManager);
    }
    public void Undo(){
        if(undoManager.canUndo()) undoManager.undo();
    }
    public void Cut(){
        Main.edit_text_area.cut();
    }
    public void Copy(){
        Main.edit_text_area.copy();
    }
    public void Paste(){
        Main.edit_text_area.paste();
    }
    public void Redo(){
        if(undoManager.canRedo()) undoManager.redo();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == Main.item_undo) Undo();
        if(e.getSource() == Main.item_redo) Redo();
        if(e.getSource() == Main.item_cut) Cut();
        if(e.getSource() == Main.item_copy) Copy();
        if(e.getSource() == Main.item_paste) Paste();


    }
}
