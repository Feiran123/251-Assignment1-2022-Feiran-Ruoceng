import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Help extends JFrame implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Main.item_about) {
            new about_Window();
        }
    }
    public Help(){
        Main.item_about.addActionListener(this);
    }
}
