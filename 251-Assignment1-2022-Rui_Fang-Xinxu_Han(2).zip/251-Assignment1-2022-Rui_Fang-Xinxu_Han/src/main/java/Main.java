import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;


public class Main extends JFrame{

        protected JMenuBar menuBar;
        //the menu in the menu bar
        protected static JMenu menu_File,menu_Search, menu_View, menu_Manage,menu_Help,menu_Format;
        //file
        protected static JMenuItem item_new,item_open,item_export_to_PDF,item_save,item_exit;
        //manage
        protected static JMenuItem item_undo,item_redo,item_cut,item_copy,item_paste;
        //help
        protected static JMenuItem item_about;
        //format
        protected static JMenuItem item_word_format;

        protected static JTextArea edit_text_area;

        protected JScrollPane scroll_bar;

    public static JTextArea getEdit_text_area() {
        return edit_text_area;
    }


        public Main() {
            initMenuBar();
            initFontfunction();
            initEditArea();
            //initListener();
            new Fontfunction();
            new Help();
            new Filefunction();
            new Managefunction();
            this.add(scroll_bar);
            this.setJMenuBar(menuBar);
            this.setSize(800,600);
            this.setTitle("Test Editor");
            this.setVisible(true);
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }


        public void initEditArea() {
            edit_text_area = new JTextArea();
            scroll_bar = new JScrollPane(edit_text_area);
            scroll_bar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scroll_bar.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            edit_text_area.setBackground(Color.white);
            edit_text_area.setForeground(Color.black);
            edit_text_area.setFont(new Font("Arial", Font.PLAIN, 12));

        }
        public void initFontfunction(){
        item_word_format.addActionListener(e -> {
            Fontfunction fontDialog = new Fontfunction(edit_text_area.getFont());
            fontDialog.setVisible(true);
        });
    }
        public void initMenuBar() {
            //File-function
            menuBar = new JMenuBar();
            menu_File = new JMenu("File");
            menu_File.setMnemonic('f');
            item_new = new JMenuItem("New");
            item_open = new JMenuItem("Open");
            item_save = new JMenuItem("Save");
            item_export_to_PDF = new JMenuItem("Export to PDF");
            item_exit = new JMenuItem("Exit");
            menu_File.add(item_new);
            menu_File.add(item_open);
            menu_File.add(item_save);
            menu_File.add(item_export_to_PDF);
            menu_File.add(item_exit);

            //Search-function
            menu_Search = new JMenu("Search");
            menu_Search.setMnemonic('s');

            //View-function
            menu_View = new JMenu("View");
            menu_View.setMnemonic('v');

            //Manage-function
            menu_Manage = new JMenu("Manage");
            menu_Manage.setMnemonic('m');
            item_undo = new JMenuItem("Undo");
            item_redo = new JMenuItem("Redo");
            item_cut = new JMenuItem("Cut");
            item_copy = new JMenuItem("Copy");
            item_paste = new JMenuItem("Paste");

            menu_Manage.add(item_undo);
            menu_Manage.add(item_redo);
            menu_Manage.add(item_cut);
            menu_Manage.add(item_copy);
            menu_Manage.add(item_paste);


            //Help-function
            menu_Help = new JMenu("Help");
            menu_Help.setMnemonic('h');
            item_about = new JMenuItem("About");
            menu_Help.add(item_about);

            //Format-function
            menu_Format = new JMenu("Format");
            menu_Format.setMnemonic('o');
            item_word_format = new JMenuItem("Font(F)");
            item_word_format.setAccelerator(KeyStroke.getKeyStroke('F', InputEvent.CTRL_MASK,false));//给item添加快捷键
            menu_Format.add(item_word_format);
            menuBar.add(menu_File);
            menuBar.add(menu_Search);
            menuBar.add(menu_View);
            menuBar.add(menu_Manage);
            menuBar.add(menu_Format);
            menuBar.add(menu_Help);


        }




        public static void main(String[] args) {
            Main m = new Main();
        }
    }
