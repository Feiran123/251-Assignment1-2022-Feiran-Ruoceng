import javax.swing.*;

public class about_Window extends JFrame{

    private JButton btn_ok;
    private JLabel about_label;

    private JPanel panel ;
    private BoxLayout boxlayout;

    /**
     * 窗口的构造函数
     */
    public about_Window() {
        panel = new JPanel();
        boxlayout = new BoxLayout(panel,BoxLayout.Y_AXIS);
        panel.setLayout(boxlayout);

        btn_ok = new JButton("OK");
        btn_ok.setAlignmentX(BOTTOM_ALIGNMENT);
        String strMsg1 = "Short Information Of Members: ";
        String strMsg2 = "member1: Rui Fang, id: 21012748, a student who experts in coding.";
        String strMsg3 = "member2: Xinxu Han, id: 21012671, a student who works hard in this course.";
        String strMsg = "<html><body>" + strMsg1 + "<br>" + strMsg2 + "<br>" + strMsg3 + "<body></html>";
        about_label = new JLabel(strMsg);


        about_label.setAlignmentX(CENTER_ALIGNMENT);


        panel.add(about_label);
        panel.add(btn_ok);


        this.add(panel);
        this.setSize(300,200);
        this.setTitle("About");
        this.setVisible(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        btn_ok.addActionListener(e->{
            this.dispose();
        });
    }
}