

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.*;

public class Filefunction extends JFrame implements ActionListener {
    FileDialog openDia = new FileDialog(this,"Open",FileDialog.LOAD);
    FileDialog saveDia = new FileDialog(this,"Save",FileDialog.SAVE);
    FileDialog export2pdf = new FileDialog(this,"Export",FileDialog.SAVE);
    public Filefunction(){
        Main.item_new.addActionListener(this);
        Main.item_new.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
        Main.item_open.addActionListener(this);
        Main.item_open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        Main.item_save.addActionListener(this);
        Main.item_save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        Main.item_exit.addActionListener(this);
        Main.item_exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
        Main.item_export_to_PDF.addActionListener(this);
    }

    public void New(){
        int a = JOptionPane.showConfirmDialog(null, "This will clear the unsaved content. Are you sure to continue?", "Warning",JOptionPane.YES_NO_OPTION);
        if(a == 0) Main.edit_text_area.setText("");
    }
    public void Open(){
        int a = JOptionPane.showConfirmDialog(null, "This will clear the unsaved content. Are you sure to continue?", "Warning",JOptionPane.YES_NO_OPTION);
        if(a == 0) {
            openDia.setVisible(true);
            String dirPath = openDia.getDirectory();  //获取打开文件路径并保存
            String fileName = openDia.getFile();  //获取文件名称并保存
            //判断打开路径或目录是否为空，则返回空
            if (dirPath == null || fileName == null) {
                return;
            }
            Main.edit_text_area.setText("");//清空文本
            File filefunctionO = new File(dirPath, fileName);
            try {
                BufferedReader bufr = new BufferedReader(new FileReader(filefunctionO));      //尝试从文件中读取内容
                String line = null;  //变量字符串初始化为空
                while ((line = bufr.readLine()) != null) {
                    Main.edit_text_area.append(line + "\r\n");  //显示每行内容
                }
                bufr.close();   //关闭文本
            } catch (IOException er1) {
                throw new RuntimeException("Failed to read the file！");
            }
        }
    }
    public void Save(){
        File fileS = null;
        if(fileS == null){
            saveDia.setVisible(true);  //显示保存文件对话框
            String dirPath = saveDia.getDirectory();  //获取保存文件路径并保存到字符串中
            String fileName = saveDia.getFile();  //获取保存文件名称并保存到字符串中

            if(dirPath == null || fileName == null)  //判断路径和文件是否为空
                return;  //返回空值

            fileS = new File(dirPath,fileName);  //文件不为空，新建一个路径和名称
        }
        try{
            BufferedWriter bufw = new BufferedWriter(new FileWriter(fileS));    //尝试从文件中读取内容
            String text = Main.edit_text_area.getText();  //获取文本内容
            bufw.write(text);  //将获取文本内容写入到字符输出流
            bufw.close();  //关闭文件
        }catch(IOException er){
            throw new RuntimeException("文件保存失败！");
        }
    }
    public void Export_to_PDF() throws FileNotFoundException, DocumentException {

        Document document =new Document(PageSize.A4,50,50,30,20);
        String text = Main.edit_text_area.getText();
        export2pdf.setVisible(true);
        String dirPath = export2pdf.getDirectory();  //获取保存文件路径并保存到字符串中
        System.out.println(dirPath);
        String fileName = export2pdf.getFile() + ".pdf";
        System.out.println(fileName);
        // 2.建立一个书写器(Writer)与document对象关联，通过书写器(Writer)可以将文档写入到磁盘中。
        // 创建 PdfWriter 对象 第一个参数是对文档对象的引用，第二个参数是文件的实际名称，在该名称中还会给出其输出路径。
        PdfWriter.getInstance(document, new FileOutputStream(dirPath+'/'+fileName));

        // 3.打开文档
        document.open();

        // 4.添加一个内容段落
        document.add(new Paragraph(text));

        // 5.关闭文档
        document.close();

    }
    public void Exit(){
        int a = JOptionPane.showConfirmDialog(null, "This will clear the unsaved content. Are you sure to continue?", "Warning",JOptionPane.YES_NO_OPTION);
        if(a == 0) System.exit(0);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Main.item_new) {
            New();
        }
        if(e.getSource() == Main.item_open){
            Open();
        }
        if (e.getSource() == Main.item_save){
            Save();
        }
        if(e.getSource() == Main.item_export_to_PDF){
            try {
                Export_to_PDF();
            } catch (FileNotFoundException | DocumentException ex) {
                ex.printStackTrace();
            }
        }
        if(e.getSource() == Main.item_exit){
            Exit();
        }
    }
}